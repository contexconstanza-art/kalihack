# Bug Report

## Contexto
Crear reportes de bug bounty de alta calidad con toda la información necesaria para que los cazadores de bugs puedan reproducir y validar los hallazgos.

## Prompt

```
Genera un reporte de bug bounty estructurado con:
1. Título claro y descriptivo del hallazgo
2. Identificación del objetivo (URL, dominio, aplicación)
3. Nivel de severidad (Critical, High, Medium, Low)
4. Pasos para reproducir el hallazgo (con capturas de pantalla o videos)
5. Demostración del impacto (PoC, datos extraídos, acceso no autorizado)
6. Evidencia técnica (logs, capturas de pantalla, archivos de prueba)
7. Referencia a vulnerabilidades similares (CVE, CVSS si aplica)
8. Sugerencias de remediación y mitigación
9. Contexto adicional (alcance, alcance del bug bounty program)

Formato recomendado: Markdown con secciones claras y bien definidas.
```

## Variables
- `title`: Título del hallazgo
- `target`: URL o dominio del objetivo
- `severity`: Nivel de severidad
- `steps_to_reproduce`: Instrucciones detalladas
- `evidence`: Evidencia técnica
- `output`: Formato de salida (markdown, PDF)

## Ejemplo de Uso

```
Genera un reporte de bug bounty para SQL Injection encontrado en https://example.com
```

## Salida Esperada
Un documento de reporte completo listo para enviar al programa de bug bounty.
```

## Notas
- Sé conciso pero completo en la descripción.
- Incluye siempre pasos de reproducción claros.
- Documenta el impacto real en el negocio.
- Sigue las directrices del programa específico.
```