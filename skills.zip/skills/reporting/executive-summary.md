# Executive Summary

## Contexto
Crear resúmenes ejecutivos para reportes de seguridad dirigidos a directivos y stakeholders no técnicos.

## Prompt

```
Crea un resumen ejecutivo para un reporte de seguridad con:
1. Descripción general del hallazgo en lenguaje no técnico
2. Impacto potencial en el negocio (pérdida de datos, reputación, finanzas)
3. Nivel de riesgo (Crítico, Alto, Medio, Bajo)
4. Acciones recomendadas para mitigación
5. Tiempo estimado para explotación y complejidad
6. Contexto del alcance del test (qué se probó y en qué condiciones)

Mantén un tono profesional y orientado a la toma de decisiones.
Utiliza viñetas y un lenguaje claro y directo.
```

## Variables
- `finding_title`: Título del hallazgo
- `business_impact`: Impacto en el negocio
- `risk_level`: Nivel de riesgo
- `recommendations`: Acciones recomendadas
- `output`: Formato de salida (markdown, PDF)

## Ejemplo de Uso

```
Crea un resumen ejecutivo para SQL Injection en el sistema de pagos del cliente.
```

## Salida Esperada
Un documento de resumen ejecutivo de 1-2 páginas listo para presentar a la dirección.
```

## Notas
- Enfócate en el "qué" y "por qué", no en el "cómo".
- Hazlo comprensible para directivos no técnicos.
- Siempre incluye recomendaciones claras de mitigación.
```