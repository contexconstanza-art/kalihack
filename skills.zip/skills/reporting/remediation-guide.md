# Remediation Guide

## Contexto
Proporcionar guías detalladas de corrección para que los equipos de desarrollo y operaciones puedan arreglar las vulnerabilidades encontradas.

## Prompt

```
Crea una guía de remediación para la vulnerabilidad identificada con:
1. Descripción de la vulnerabilidad y sus causas raíz
2. Código vulnerable y ejemplo de cómo fue explotado
3. Solución o parche recomendado
4. Pasos para implementar la corrección
5. Pruebas de verificación para confirmar que la vulnerabilidad fue arreglada
6. Mejores prácticas para evitar recurrencia
7. Referencias a documentación oficial y CVE si aplica

Sé específico con los números de línea, funciones y archivos afectados cuando sea posible.
```

## Variables
- `vuln_type`: Tipo de vulnerabilidad
- `vulnerable_code`: Código vulnerable o descripción
- `remediation`: Solución o parche recomendado
- `verification_steps`: Pasos para verificar la corrección
- `output`: Formato de salida (markdown, HTML)

## Ejemplo de Uso

```
Crea una guía de remediación para SQL Injection en la función de búsqueda de productos.
```

## Salida Esperada
Un documento técnico con la guía completa de corrección y verificación.
```

## Notas
- Incluye siempre pasos de verificación.
- Referencia documentación oficial cuando sea posible.
- Sugiere mejores prácticas de programación segura.
```