# Pipeline Setup

## Contexto
Configurar pipelines de CI/CD para automatizar el escaneo de seguridad continuo y la integración en el ciclo de desarrollo.

## Prompt

```
Diseña un pipeline de seguridad automatizado para el objetivo:
1. Define las etapas de escaneo (SAST, DAST, SCA, Secret scanning)
2. Selecciona las herramientas (Semgrep, Nuclei, Trivy, Gitleaks, etc.)
3. Configura triggers (push, PR, schedule, release)
4. Define políticas de gates (fallar build en vulnerabilidades críticas)
5. Configura notificaciones (Slack, Email, Jira, GitHub Issues)
6. Implementa reportes y dashboards (SARIF, HTML, JSON)

Ejemplo de pipeline GitHub Actions:
```yaml
name: Security Pipeline
on: [push, pull_request]
jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: SAST
        uses: github/codeql-action/analyze@v2
      - name: DAST
        run: nuclei -t cves/ -u https://staging.example.com
      - name: Secret Scan
        uses: gitleaks/gitleaks-action@v2
```

Herramientas recomendadas por etapa:
- SAST: Semgrep, CodeQL, SonarQube
- DAST: Nuclei, OWASP ZAP, Nikto
- SCA: Trivy, Snyk, Dependabot
- Secrets: Gitleaks, TruffleHog
- Container: Trivy, Grype, Docker Scout
```

## Variables
- `platform`: GitHub Actions, GitLab CI, Jenkins, Azure DevOps
- `target_env`: Development, Staging, Production
- `tools`: Lista de herramientas a integrar
- `severity_threshold`: Umbral de severidad para fallar build
- `output`: Formato de salida (YAML pipeline file)

## Ejemplo de Uso

```
Configura un pipeline de seguridad para una aplicación Node.js en GitHub Actions
```

## Salida Esperada
Un archivo de configuración de pipeline listo para usar.
```

## Notas
- Integra escaneo temprano (shift-left) en el ciclo de desarrollo.
- Usa SARIF para integrar resultados en GitHub/GitLab Security tab.
- Configura excepciones documentadas para falsos positivos conocidos.
- Mantén el pipeline rápido (< 10 min) para no bloquear desarrollo.
```