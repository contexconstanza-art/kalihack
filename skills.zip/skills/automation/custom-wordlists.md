# Custom Wordlists

## Contexto
Crear wordlists personalizadas y optimizadas para cada objetivo, mejorando la eficiencia del fuzzing y enumeración.

## Prompt

```
Genera una wordlist personalizada para el objetivo proporcionado:
1. Analiza el stack tecnológico y arquitectura del objetivo
2. Identifica patrones de naming (APIs, endpoints, parámetros)
3. Incluye palabras específicas del dominio (nombres de productos, servicios, etc.)
4. Combina wordlists base (SecLists, fuzzdb) con términos específicos
5. Optimiza para el tipo de fuzzing (directorios, parámetros, subdominios, APIs)

Estructura sugerida:
- Base wordlist (común a todos los targets)
- Tech-specific wordlist (por tecnología detectada)
- Target-specific wordlist (específica del dominio)
- Mutation rules (para generar variaciones)

Herramientas recomendadas:
- cewl (extraer palabras del sitio web)
- crunch (generar combinaciones)
- rsact (generar wordlists contextuales)
```

## Variables
- `target`: URL o dominio del objetivo
- `tech_stack`: Stack tecnológico detectado
- `wordlist_type`: Tipo (directories, parameters, subdomains, apis)
- `base_wordlists`: Wordlists base a combinar
- `output`: Formato de salida (txt file)

## Ejemplo de Uso

```
Genera una wordlist para fuzzing de APIs en una aplicación React/Node.js
```

## Salida Esperada
Un archivo de texto con la wordlist optimizada, listo para usar con ffuf, feroxbuster, etc.
```

## Notas
- Mantén las wordlists actualizadas con nuevos términos.
- Usa cewl para extraer términos del sitio web actual.
- Combina wordlists generales con específicas del target.
- Documenta las fuentes y metodología usada.
```