# Nuclei Templates

## Contexto
Crear plantillas personalizadas para Nuclei que permitan escanear vulnerabilidades específicas de forma automatizada y escalable.

## Prompt

```
Crea una plantilla Nuclei personalizada para detectar la vulnerabilidad especificada:
1. Define la lógica de detección (request/response matching)
2. Especifica los matchers (regex, dsl, status code, etc.)
3. Incluye metadata (severity, tags, author, references)
4. Prueba la plantilla contra objetivos conocidos
5. Optimiza para falsos positivos/negativos

Estructura básica de plantilla:
```yaml
id: CVE-XXXX-XXXX
info:
  name: Nombre descriptivo
  author: Tu nombre
  severity: high/critical/medium/low
  tags: tag1,tag2
  reference:
    - URL de referencia
http:
  - method: GET
    path:
      - "{{BaseURL}}/path"
    matchers:
      - type: regex
        regex:
          - "patrón a buscar"
```

Usa la sintaxis YAML de Nuclei y sigue las mejores prácticas de la comunidad.
```

## Variables
- `vuln_id`: Identificador de la vulnerabilidad (CVE, CWE, o custom)
- `vuln_name`: Nombre descriptivo
- `target_path`: Ruta o endpoint a testear
- `matcher_type`: Tipo de matcher (regex, dsl, status, word, binary)
- `severity`: Nivel de severidad
- `output`: Formato de salida (YAML file)

## Ejemplo de Uso

```
Crea una plantilla Nuclei para detectar SQL Injection en parámetros GET.
```

## Salida Esperada
Un archivo YAML listo para usar con `nuclei -t template.yaml`
```

## Notas
- Mantén las plantillas simples y enfocadas.
- Usa variables de Nuclei ({{BaseURL}}, {{Hostname}}, etc.).
- Prueba siempre contra targets reales antes de usar en producción.
- Contribuye a la comunidad si la plantilla es genérica.
```