# 🎯 Custom Skills - Bug Bounty & Pentesting

Colección de skills (prompts especializados) para automatizar y estandarizar tareas de bug bounty y pentesting.

## 📁 Estructura

```
skills/
├── recon/                 # Reconocimiento y enumeración
│   ├── subdomain-enum.md
│   ├── tech-stack.md
│   ├── api-discovery.md
│   └── cloud-recon.md
├── vuln-analysis/         # Análisis de vulnerabilidades
│   ├── sql-injection.md
│   ├── xss-analysis.md
│   ├── ssrf.md
│   ├── idor.md
│   ├── auth-bypass.md
│   ├── race-condition.md
│   └── logic-flaws.md
├── exploitation/          # Explotación y PoC
│   ├── poc-generator.md
│   ├── chain-attacks.md
│   └── privilege-escalation.md
├── reporting/             # Reportes y documentación
│   ├── bug-report.md
│   ├── executive-summary.md
│   └── remediation-guide.md
├── automation/            # Automatización y workflows
│   ├── nuclei-templates.md
│   ├── custom-wordlists.md
│   └── pipeline-setup.md
└── methodology/           # Metodologías y checklists
    ├── web-app-checklist.md
    ├── api-checklist.md
    ├── mobile-checklist.md
    └── cloud-checklist.md
```

## 🚀 Uso Rápido

Cada skill es un archivo Markdown con:
- **Contexto**: Qué hace y cuándo usarlo
- **Prompt**: El prompt optimizado para el LLM
- **Variables**: Parámetros que debes rellenar
- **Ejemplos**: Casos de uso reales
- **Output esperado**: Formato de respuesta

### Ejemplo de uso

```bash
# Copia el prompt del skill y rellena las variables
# Pégalo en tu LLM favorito (Claude, GPT, etc.)
```

## 📋 Catálogo de Skills

### 🔍 Recon
| Skill | Descripción | Uso |
|-------|-------------|-----|
| Subdomain Enum | Descubrir subdominios activos | Enumeración pasiva/activa |
| Tech Stack | Identificar stack tecnológico | Análisis de superficie |
| API Discovery | Encontrar y documentar APIs | Recon de API |
| Cloud Recon | Detectar infraestructura en la nube | Misconfig cloud |

### 🐛 Vuln Analysis
| Skill | Descripción | Uso |
|-------|-------------|-----|
| SQL Injection | Detectar y explotar SQLi | Inyección de queries |
| XSS | Detectar XSS (reflected/stored/DOM) | Inyección de scripts |
| SSRF | Detectar SSRF | Acceso a recursos internos |
| IDOR | Detectar IDOR | Acceso no autorizado |
| Auth Bypass | Detectar bypass de autenticación | Bypass de seguridad |
| Race Condition | Detectar race conditions | Concurrencia |
| Logic Flaws | Detectar fallos de lógica de negocio | Manipulación de flujo |

### 💥 Exploitation
| Skill | Descripción | Uso |
|-------|-------------|-----|
| PoC Generator | Generar pruebas de concepto | Demostración de impacto |
| Chain Attacks | Crear cadenas de ataque | Impacto multi-vuln |
| Privilege Escalation | Detectar escalada de privilegios | Acceso root |

### 📄 Reporting
| Skill | Descripción | Uso |
|-------|-------------|-----|
| Bug Report | Generar reportes de bug | Plataformas (H1, BC) |
| Executive Summary | Crear resúmenes ejecutivos | Audiencias no técnicas |
| Remediation Guide | Crear guías de corrección | Fixes para devs |

### 🤖 Automation
| Skill | Descripción | Uso |
|-------|-------------|-----|
| Nuclei Templates | Crear plantillas Nuclei | Escaneo automatizado |
| Custom Wordlists | Generar wordlists optimizadas | Fuzzing eficiente |
| Pipeline Setup | Configurar pipelines CI/CD | Shift-left security |

### 📋 Methodology
| Skill | Descripción | Uso |
|-------|-------------|-----|
| Web App Checklist | Checklist de seguridad web | Pentest completo |
| API Checklist | Checklist para APIs | Seguridad API |
| Mobile Checklist | Checklist para apps móviles | Seguridad móvil |
| Cloud Checklist | Checklist para cloud | Seguridad cloud |

## 🎯 Flujo de Trabajo Recomendado

1. **Recon**: `subdomain-enum` → `tech-stack` → `api-discovery`
2. **Vuln Analysis**: `sql-injection` → `xss` → `ssrf` → `idor` → `auth-bypass` → ...
3. **Exploitation**: `poc-generator` → `chain-attacks` → `priv-esc`
4. **Reporting**: `bug-report` → `executive-summary` → `remediation-guide`

## 📝 Cómo Usar

1. Navega al directorio del skill que necesitas
2. Lee el archivo `.md`
3. Rellena las variables
4. Copia el prompt
5. Pégalo en tu LLM favorito

## 🔧 Personalización

Crea variaciones de los skills según tus necesidades:
- Añade técnicas específicas de tu experiencia
- Incorpora vectores de ataque personalizados
- Actualiza wordlists y plantillas
- Agrega referencias a CVEs y CWE específicos

---

## 🎯 Sistema Multi-Agente (7 skills adicionales)

```
multi-agent/
├── orchestrator.md        # Modelo principal / coordinador
├── agent-recon.md         # Reconocimiento (pasivo/activo)
├── agent-vuln-analysis.md # Detección de vulnerabilidades
├── agent-exploitation.md  # Generación de PoCs, chains, escalada
├── agent-reporting.md     # Reportes de bug bounty
├── escalation-handler.md  # Análisis de fallos, bypass strategies
└── state-manager.md       # Estado compartido entre agentes
```

**Objetivo**: Un modelo principal (Orchestrator) coordina y delega a modelos especializados. Si alguno se queda atascado, el **Escalation Handler** analiza por qué falló y propone métodos alternativos (WAF bypass, diferentes parámetros, otro agente, etc.).

### Flujo completo (ver `multi-agent/workflow-example.md`)
```
INIT → RECON → VULN_ANALYSIS → EXPLOITATION → REPORTING → COMPLETE
                ↓                    ↓
           ESCALATION HANDLER  (si algún agente se bloquea)
```

### Uso del Orchestrator
1. Usa `multi-agent/orchestrator.md` como **System Prompt** principal
2. Cada respuesta JSON del orchestrator indica qué agente invocar y con qué parámetros
3. Copia el prompt del agente indicado, rellena con los params, pégalo en tu LLM
4. Vuelve al paso 2 hasta `decision: COMPLETE`

> **Tip**: Para un workflow completo, combina skills de diferentes categorías en un solo prompt.