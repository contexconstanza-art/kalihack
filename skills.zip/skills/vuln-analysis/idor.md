# IDOR Analysis

## Contexto
Identificar vulnerabilidades de Insecure Direct Object Reference (IDOR) en aplicaciones web, permitiendo el acceso no autorizado a recursos de otros usuarios.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de IDOR. Para cada parámetro de entrada:
1. Determina si es vulnerable a IDOR (parámetros de objeto, URLs, IDs)
2. Identifica el tipo de recurso accedido (archivos, usuarios, pedidos, etc.)
3. Prueba payloads para acceder a recursos de otros usuarios
4. Determina si es posible acceder a datos sensibles de otros usuarios
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con IDs de usuario
- Análisis de parámetros GET/POST
- Inspección de respuestas HTTP
```

## Variables
- `target`: URL del objetivo
- `parameter`: Parámetro a analizar (ej: user_id, file_id, order_id)
- `resource_type`: Tipo de recurso accedido (archivos, usuarios, pedidos, etc.)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el parámetro 'user_id' de https://example.com/profile.php para detectar IDOR.
```

## Salida Esperada
Un informe detallado con el tipo de IDOR, payloads usados, y resultados.
```

## Notas
- Prioriza parámetros que acceden a recursos de usuarios.
- Verifica si hay autenticación y autorización adecuadas.
- Documenta los payloads y resultados para el reporte.
```