# Business Logic Flaws Analysis

## Contexto
Identificar vulnerabilidades de lógica de negocio en aplicaciones web, permitiendo explotar flujos de trabajo mal diseñados.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de lógica de negocio. Para cada flujo de trabajo crítico:
1. Determina si hay fallos en la lógica de negocio (bypass de pasos, manipulación de precios, etc.)
2. Identifica el tipo de flujo (compra, registro, recuperación de contraseña, etc.)
3. Prueba manipulaciones de parámetros para alterar el flujo
4. Determina si es posible explotar el flujo para beneficio propio
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con manipulaciones de parámetros
- Análisis de flujos de trabajo multi-paso
- Inspección de respuestas HTTP
```

## Variables
- `target`: URL del objetivo
- `workflow`: Flujo de trabajo a analizar (ej: checkout, password_reset, registration)
- `parameter`: Parámetro a manipular (ej: price, quantity, step)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el flujo de compra de https://example.com/checkout.php para detectar fallos de lógica de negocio.
```

## Salida Esperada
Un informe detallado con el tipo de fallo, payloads usados, y resultados.
```

## Notas
- Prioriza flujos que manejan dinero o datos sensibles.
- Verifica si hay validaciones del lado del servidor.
- Documenta los payloads y resultados para el reporte.
```