# XSS Analysis

## Contexto
Identificar vulnerabilidades de Cross-Site Scripting (XSS) en aplicaciones web, permitiendo la ejecución de scripts maliciosos en el navegador de la víctima.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de XSS. Para cada parámetro de entrada:
1. Determina si es vulnerable a XSS (reflejado, almacenado, DOM-based)
2. Identifica el contexto de salida (HTML, attribute, JavaScript, CSS)
3. Determina la longitud del payload y posibles bloqueos (WAF, filtros)
4. Prueba payloads básicos y avanzados (img, svg, script, onerror, etc.)
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con payloads
- Análisis de código fuente (si es público)
- Inspección de parámetros GET/POST
```

## Variables
- `target`: URL del objetivo
- `parameter`: Parámetro a analizar (ej: q, search, name)
- `xss_type`: Tipo de XSS (reflected, stored, DOM-based)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el parámetro 'q' de https://example.com/search.php para detectar XSS.
```

## Salida Esperada
Un informe detallado con el tipo de XSS, payloads usados, y resultados.
```

## Notas
- Prioriza parámetros que se reflejan en la respuesta HTML.
- Verifica si hay Content Security Policy (CSP) que mitigue el XSS.
- Documenta los payloads y resultados para el reporte.
```