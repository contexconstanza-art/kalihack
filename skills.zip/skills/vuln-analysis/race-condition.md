# Race Condition Analysis

## Contexto
Identificar vulnerabilidades de condición de carrera (race condition) en aplicaciones web, permitiendo explotar la concurrencia para obtener resultados inesperados.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de race condition. Para cada operación crítica:
1. Determina si es vulnerable a race condition (transferencias, compras, registro, etc.)
2. Identifica el tipo de operación (financiera, de estado, de concurrencia)
3. Prueba payloads con múltiples solicitudes simultáneas
4. Determina si es posible explotar la concurrencia para beneficio propio
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con herramientas de concurrencia (curl, scripts)
- Análisis de operaciones que modifican estado
- Inspección de respuestas HTTP
```

## Variables
- `target`: URL del objetivo
- `operation`: Operación a analizar (ej: transfer, purchase, register)
- `concurrency_level`: Nivel de concurrencia a probar (ej: 10, 50, 100)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza la transferencia de fondos de https://example.com/transfer.php para detectar race condition.
```

## Salida Esperada
Un informe detallado con el tipo de race condition, payloads usados, y resultados.
```

## Notas
- Prioriza operaciones que modifican estado crítico (dinero, inventario, etc.).
- Verifica si hay bloqueos o transacciones atómicas.
- Documenta los payloads y resultados para el reporte.
```