# SSRF Analysis

## Contexto
Identificar vulnerabilidades de Server-Side Request Forgery (SSRF) en aplicaciones web, permitiendo acceder a servicios internos o externos no autorizados.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de SSRF. Para cada parámetro de entrada:
1. Determina si es vulnerable a SSRF (URL injection, parameter pollution)
2. Identifica el tipo de SSRF (blind, semi-blind, full response)
3. Prueba payloads para acceder a servicios internos (localhost, 169.254.169.254, etc.)
4. Determina si es posible acceder a metadatos de cloud (AWS, GCP, Azure)
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con URLs internas
- Análisis de parámetros GET/POST
- Inspección de respuestas HTTP
```

## Variables
- `target`: URL del objetivo
- `parameter`: Parámetro a analizar (ej: url, callback, webhook)
- `ssrf_type`: Tipo de SSRF (blind, semi-blind, full response)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el parámetro 'url' de https://example.com/fetch.php para detectar SSRF.
```

## Salida Esperada
Un informe detallado con el tipo de SSRF, payloads usados, y resultados.
```

## Notas
- Prioriza parámetros que realizan solicitudes HTTP del lado del servidor.
- Verifica si hay listas negras de IPs o dominios.
- Documenta los payloads y resultados para el reporte.
```