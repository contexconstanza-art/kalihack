# Authentication Bypass Analysis

## Contexto
Identificar vulnerabilidades de bypass de autenticación en aplicaciones web, permitiendo acceder a áreas protegidas sin credenciales válidas.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de bypass de autenticación. Para cada mecanismo de autenticación:
1. Determina si es vulnerable a bypass (SQLi en login, JWT manipulation, session fixation, etc.)
2. Identifica el tipo de autenticación (form-based, JWT, OAuth, SAML, etc.)
3. Prueba payloads para bypass (SQLi, JWT none algorithm, session fixation, etc.)
4. Determina si es posible acceder a áreas protegidas sin credenciales
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- Manual testing con payloads de bypass
- Análisis de tokens JWT
- Inspección de cookies de sesión
```

## Variables
- `target`: URL del objetivo
- `auth_type`: Tipo de autenticación (form-based, JWT, OAuth, SAML, etc.)
- `parameter`: Parámetro a analizar (ej: username, password, token)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el formulario de login de https://example.com/login.php para detectar bypass de autenticación.
```

## Salida Esperada
Un informe detallado con el tipo de bypass, payloads usados, y resultados.
```

## Notas
- Prioriza mecanismos de autenticación débiles o mal implementados.
- Verifica si hay rate limiting en login.
- Documenta los payloads y resultados para el reporte.
```