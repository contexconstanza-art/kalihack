# SQL Injection Analysis

## Contexto
Identificar y explotar vulnerabilidades de inyección SQL en aplicaciones web, permitiendo la extracción o modificación de datos.

## Prompt

```
Analiza el objetivo web proporcionado para detectar vulnerabilidades de SQL Injection. Para cada parámetro de entrada:
1. Determina si es vulnerable a SQLi (boolean-based, error-based, time-based, UNION-based)
2. Identifica el tipo de base de datos (MySQL, PostgreSQL, MSSQL, Oracle, etc.)
3. Determina el número de columnas y los nombres de tablas
4. Extrae datos sensibles (contraseñas, tokens, información de usuario)
5. Documenta el payload utilizado y los resultados obtenidos

Usa herramientas como:
- sqlmap, manual testing con payloads
- Análisis de headers y parámetros GET/POST
- Análisis de errores del sistema
```

## Variables
- `target`: URL del objetivo
- `parameter`: Parámetro a analizar (ej: id, user, search)
- `db_type`: Tipo de base de datos (MySQL, PostgreSQL, MSSQL, Oracle, etc.)
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza el parámetro 'id' de https://example.com/product.php para detectar SQL Injection.
```

## Salida Esperada
Un informe detallado con el tipo de SQLi, payloads usados, y datos extraídos.
```

## Notas
- Prioriza parámetros en URLs que interactúan con bases de datos.
- Verifica si es blind SQLi (time-based o boolean-based).
- Documenta los payloads y resultados para el reporte.
```