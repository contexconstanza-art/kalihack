# Ejemplo de Flujo de Trabajo Multi-Agente

## Escenario: Bug Bounty en https://example.com

### Paso 1: Iniciar Orchestrator
**Input al Orchestrator:**
```
Target: https://example.com
Scope: example.com, *.example.com
Time Budget: 7200 segundos
```

**Decisión del Orchestrator:**
```json
{
  "decision": "DELEGATE",
  "next_actions": [
    { "agent": "agent-recon", "task": "SUBDOMAIN_ENUM", "params": { "target": "example.com", "depth": 2 } }
  ],
  "summary": "Iniciando reconocimiento del objetivo"
}
```

### Paso 2: Recon Agent ejecuta
**Input al Recon Agent:**
```json
{ "task_id": "recon-001", "action": "SUBDOMAIN_ENUM", "params": { "target": "example.com", "depth": 2 } }
```

**Salida:**
```json
{
  "task_id": "recon-001",
  "status": "COMPLETED",
  "findings": [
    { "type": "subdomain", "value": "api.example.com" },
    { "type": "subdomain", "value": "dev.example.com" },
    { "type": "endpoint", "value": "/api/v1/users", "method": "GET" }
  ]
}
```

### Paso 3: Orchestrator delega a Vuln Analysis
**Decisión del Orchestrator:**
```json
{
  "decision": "DELEGATE",
  "next_actions": [
    { "agent": "agent-vuln-analysis", "task": "TEST_SQLI", "params": { "target": "https://example.com/product.php", "parameter": "id" } }
  ]
}
```

### Paso 4: Vuln Analysis encuentra SQLi
**Salida:**
```json
{
  "task_id": "vuln-001",
  "status": "COMPLETED",
  "vulnerabilities_found": [
    { "type": "SQL_INJECTION", "subtype": "TIME_BASED", "severity": "HIGH", "parameter": "id" }
  ]
}
```

### Paso 5: Vuln Analysis se bloquea en XSS
**Salida del Vuln Analysis:**
```json
{
  "task_id": "vuln-002",
  "status": "BLOCKED",
  "blockers": [ { "type": "waf_blocked", "waf": "Cloudflare", "technique": "REFLECTED_XSS" } ]
}
```

### Paso 6: Orchestrator activa Escalation Handler
**Decisión del Orchestrator:**
```json
{
  "decision": "ESCALATE",
  "next_actions": [
    { "agent": "escalation-handler", "task": "analyze_failure", "params": { "failed_task": "vuln-002", "failed_agent": "agent-vuln-analysis" } }
  ]
}
```

### Paso 7: Escalation Handler analiza y propone alternativas
**Salida del Escalation Handler:**
```json
{
  "decision": "RETRY_SAME_AGENT",
  "alternative_methods": [
    { "method": "Boolean-based XSS with double URL encoding", "rationale": "WAF blocks <script> but not encoded payloads" },
    { "method": "Test different parameter 'search' instead of 'q'", "rationale": "Parameter 'search' may not have same WAF rules" }
  ],
  "recommended_agent": "agent-vuln-analysis",
  "new_parameters": { "parameter": "search", "encoding": "double_url", "rate_limit": 5 }
}
```

### Paso 8: Orchestrator reintenta con nuevos parámetros
**Decisión del Orchestrator:**
```json
{
  "decision": "DELEGATE",
  "next_actions": [
    { "agent": "agent-vuln-analysis", "task": "TEST_XSS", "params": { "target": "https://example.com/search.php", "parameter": "search", "encoding": "double_url" } }
  ]
}
```

### Paso 9: XSS encontrado con método alternativo
**Salida:**
```json
{
  "task_id": "vuln-002",
  "status": "COMPLETED",
  "vulnerabilities_found": [
    { "type": "XSS", "subtype": "REFLECTED", "severity": "MEDIUM", "parameter": "search", "payload": "<svg/onload=alert(1)>" }
  ]
}
```

### Paso 10: Explotación y Reportes
**Orchestrator delega a Exploitation:**
```json
{ "agent": "agent-exploitation", "task": "GENERATE_POC", "params": { "vulnerability": { "type": "SQL_INJECTION", ... } } }
```

**Orchestrator delega a Reporting:**
```json
{ "agent": "agent-reporting", "task": "BUG_REPORT", "params": { "findings": [...], "evidence": [...] } }
```

### Paso 11: Consolidación final
**Decisión del Orchestrator:**
```json
{
  "decision": "COMPLETE",
  "summary": "Test completado: 5 vulnerabilidades confirmadas, 1 bloqueada sin alternativa, 2 escaladas resueltas exitosamente"
}
```

---

## Diagrama de Estados

```
INIT
  ↓
RECON (agent-recon)
  ↓
VULN_ANALYSIS (agent-vuln-analysis)
  ├─ COMPLETED → EXPLOITATION
  ├─ BLOCKED → ESCALATION_HANDLER
  │     ├─ RETRY_SAME_AGENT → VULN_ANALYSIS (nuevos params)
  │     ├─ SWITCH_AGENT → agent-recon / agent-exploitation
  │     └─ HUMAN_REQUIRED → STOP
  └─ FAILED → RETRY or ABANDON
    ↓
EXPLOITATION (agent-exploitation)
  ├─ COMPLETED → REPORTING
  ├─ BLOCKED → ESCALATION_HANDLER
  └─ FAILED → RETRY or ABANDON
    ↓
REPORTING (agent-reporting)
  ↓
COMPLETE
```

---

## Cómo ejecutar este sistema

### Opción 1: Manual (prompt por prompt)
1. Abre `orchestrator.md` y copia el prompt principal
2. Pégalo en tu LLM principal (Claude, GPT-4, etc.)
3. Lee la respuesta JSON del orchestrator
4. Abre el archivo del agente indicado (ej: `agent-recon.md`)
5. Copia su prompt, rellena con los params del orchestrator
6. Pégalo en tu LLM (puede ser el mismo o diferente)
7. Vuelve al paso 3 hasta que el orchestrator decida `COMPLETE`

### Opción 2: Automatizado (script)
Puedes crear un script que:
1. Lea los archivos `.md` de cada agente
2. Inyecte los parámetros dinámicamente
3. Llame a las APIs de los LLMs correspondientes
4. Orqueste el flujo basado en las respuestas JSON

### Opción 3: Modelos diferentes por agente
- **Orchestrator**: Modelo más capaz (Claude 3 Opus, GPT-4)
- **Recon**: Modelo rápido y barato (Haiku, GPT-3.5)
- **Vuln Analysis**: Modelo con buen razonamiento (Claude 3 Sonnet, GPT-4)
- **Exploitation**: Modelo técnico (GPT-4, CodeLlama)
- **Escalation Handler**: Modelo analítico (Claude 3 Opus)
- **Reporting**: Modelo con buena redacción (Claude 3 Sonnet)
- **State Manager**: Modelo simple o script local (no necesita LLM)