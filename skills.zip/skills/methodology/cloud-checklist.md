# Cloud Security Checklist

## Contexto
Checklist completo de seguridad en la nube (AWS, Azure, GCP) para identificar configuraciones inseguras y vulnerabilidades.

## Prompt

```
Genera una checklist de seguridad para infraestructura en la nube:
1. Configuración de servicios (S3, Blob, GCS)
2. Gestión de identidades y acceso (IAM, Entra ID, etc.)
3. Protección de datos (encriptación, cifrado, etc.)
4. Red y seguridad de red (VPC, Subnets, Security Groups, Firewall)
5. Monitorización y detección (CloudTrail, Monitor, etc.)
6. Gestión de secretos (KMS, Key Vault, Secrets Manager)
7. Backup y recuperación (Disaster Recovery)
8. Compliance y auditoría

Para cada categoría, incluye:
- Técnicas de testing específicas
- Herramientas recomendadas (AWS CLI, Azure CLI, gcloud, etc.)
- Indicadores de compromiso (IoC)
- Niveles de severidad típicos

Formato: Checklist accionable con marcas de verificación y notas de prioridad.
```

## Variables
- `cloud_provider`: AWS, Azure, GCP
- `account_id`: ID de cuenta o región
- `scope`: Alcance del test (recursos propios, terceros, etc.)
- `output`: Formato de salida (checklist, markdown)

## Ejemplo de Uso

```
Genera una checklist de seguridad para AWS con S3 y EC2.
```

## Salida Esperada
Una checklist estructurada para pruebas de seguridad en la nube.
```

## Notas
- Incluye técnicas específicas por proveedor (AWS, Azure, GCP).
- Verifica políticas IAM y control de acceso.
- Revisa configuraciones de recursos expuestos.
- Documenta todas las verificaciones.
```