# API Security Checklist

## Contexto
Checklist específico para seguridad de APIs, cubriendo autenticación, autorización, validación y protección de datos.

## Prompt

```
Genera una checklist de seguridad para una API REST o GraphQL:
1. Autenticación y autorización
2. Rate limiting y throttling
3. Validación de inputs y sanitización
4. Gestión de tokens y sesiones
5. Protección contra inyección y XSS
6. Control de acceso a recursos (IDOR, Broken Access)
7. Logging y monitoreo
8. Gestión de errores y información sensible

Para cada categoría, incluye:
- Técnicas de testing específicas
- Herramientas recomendadas
- Indicadores de compromiso (IoC)
- Niveles de severidad típicos

Formato: Checklist accionable con marcas de verificación y notas de prioridad.
```

## Variables
- `target`: URL de la API
- `api_type`: REST, GraphQL, SOAP, gRPC, etc.
- `auth_methods`: Métodos de autenticación (OAuth, JWT, API Key, Basic, etc.)
- `output`: Formato de salida (checklist, markdown)

## Ejemplo de Uso

```
Genera una checklist de seguridad para una API REST con JWT y OAuth.
```

## Salida Esperada
Una checklist estructurada para pruebas de seguridad de APIs.
```

## Notas
- Incluye GraphQL-specific checks (introspection, query depth, aliases).
- Considera protección contra mass assignment.
- Valida manejo de errores sin exponer información interna.
```