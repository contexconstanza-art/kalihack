# Mobile Security Checklist

## Contexto
Checklist de seguridad para aplicaciones móviles (iOS, Android), cubriendo almacenamiento local, comunicación, y análisis de binarios.

## Prompt

```
Genera una checklist de seguridad para aplicaciones móviles:
1. Análisis estático del binario
2. Gestión de secretos y API keys
3. Almacenamiento local (SharedPreferences, NSUserDefaults, Keychain)
4. Comunicación segura (HTTPS, certificados, certificados de seguridad)
5. Análisis de tráfico (man-in-the-middle, proxy)
6. Análisis del código (strings, intents, deep links, jailbreak detection)
7. Interacción con backend (API security)
8. Framework específico (React Native, Flutter, native)

Para cada categoría, incluye:
- Técnicas de testing específicas
- Herramientas recomendadas (JADX, MobSF, Frida, Burp, etc.)
- Indicadores de compromiso (IoC)
- Niveles de severidad típicos

Formato: Checklist accionable con marcas de verificación y notas de prioridad.
```

## Variables
- `target`: URL del APK o IPA, o ruta del binario
- `platform`: iOS, Android, ambos
- `backend`: URL del backend asociado
- `output`: Formato de salida (checklist, markdown)

## Ejemplo de Uso

```
Genera una checklist de seguridad para una app Android con backend Node.js.
```

## Salida Esperada
Una checklist estructurada para pruebas de seguridad móvil.
```

## Notas
- Incluye técnicas de jailbreak/root detection.
- Verifica manejo de deep links y intents maliciosos.
- Analiza el tráfico entre móvil y backend.
- Revisa el manejo de certificados TLS.
```