# Web Application Security Checklist

## Contexto
Checklist completo de seguridad para aplicaciones web, cubriendo todos los vectores de ataque comunes.

## Prompt

```
Genera una checklist de seguridad para una aplicación web, organizada por categorías:
1. Reconocimiento y enumeración
2. Autenticación y autorización
3. Gestión de sesiones y cookies
4. Entrada de datos y validación
5. API y servicios backend
6. Configuración y despliegue
7. Información sensible y secretos
8. Seguridad de infraestructura

Para cada categoría, incluye:
- Técnicas de testing específicas
- Herramientas recomendadas
- Indicadores de compromiso (IoC)
- Niveles de severidad típicos

Formato: Checklist accionable con marcas de verificación y notas de prioridad.
```

## Variables
- `target`: URL del objetivo
- `app_type`: Tipo de aplicación (SPA, API-only, tradicional, mobile backend)
- `scope`: Alcance del test (interno, externo, ambos)
- `output`: Formato de salida (checklist, markdown)

## Ejemplo de Uso

```
Genera una checklist de seguridad para una aplicación React/Node.js con API.
```

## Salida Esperada
Una checklist estructurada por categorías y subcategorías, lista para usar durante un pentest.
```

## Notas
- La checklist debe ser completa pero adaptada al stack tecnológico.
- Incluye técnicas específicas para cada categoría.
- Sugiere indicadores de compromiso para cada ataque.
```