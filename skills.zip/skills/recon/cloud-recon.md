# Cloud Recon

## Contexto
Descubrir infraestructura en la nube (AWS, Azure, GCP) de un objetivo para identificar misconfiguraciones y vulnerabilidades.

## Prompt

```
Analiza la infraestructura en la nube de un objetivo y busca:
1. Contenedores desprotegidos (Docker, Kubernetes)
2. Buckets de almacenamiento expuestos (S3, Blob, etc.)
3. Claves de API y credenciales expuestas
4. Configuraciones de seguridad débiles (S3 public, RDS sin parches)
5. Roles y políticas IAM con privilegios excesivos
6. Redes VPC mal configuradas (subnets públicas, firewall)

Usa herramientas como:
- AWS CLI, Azure CLI, gcloud
- AWS Config, Azure Policy, GCP Security Command Center
- Scan de contenedores (Trivy, Clair)
```

## Variables
- `cloud_provider`: AWS, Azure, GCP
- `target`: URL o nombre de la cuenta
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Reconoce la infraestructura en la nube de example.com.
```

## Salida Esperada
Un informe de misconfiguraciones en la nube.
```

## Notas
- Prioriza recursos expuestos sin protección (S3 public, RDS sin parches).
- Verifica si hay servicios de caché expuestos (Redis, Memcached).
- Documenta las vulnerabilidades de seguridad en la nube.
```