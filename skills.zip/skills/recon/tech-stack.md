# Technology Stack Discovery

## Contexto
Identificar el stack tecnológico de una aplicación web (servidor, base de datos, framework, etc.) para guiar el análisis de vulnerabilidades.

## Prompt

```
Dado un URL objetivo, determina:
1. Servidor web (Nginx, Apache, IIS, etc.)
2. Versión del servidor web
3. Base de datos utilizada (MySQL, PostgreSQL, MongoDB, etc.)
4. Framework frontend/backend (React, Angular, Django, Rails, etc.)
5. CORS y configuración de seguridad
6. Herramientas de build y despliegue

Usa herramientas como:
- curl, nmap, amass, sublist2
- DNS lookup (dig, nslookup)
- Análisis de headers HTTP
- Inspección de código fuente (si es público)
```

## Variables
- `url`: URL del objetivo
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Analiza https://example.com y determina su stack tecnológico.
```

## Salida Esperada
Un informe estructurado con los componentes tecnológicos detectados.
```

## Notas
- La información del stack ayuda a priorizar la exploración (ej: bases de datos expuestas son críticas).
- Combina con análisis de vulnerabilidades específicas del stack (SQLi en MySQL, XSS en React, etc.)
```