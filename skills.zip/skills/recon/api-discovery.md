# API Discovery

## Contexto
Encontrar y documentar APIs disponibles en un objetivo web, incluyendo endpoints, métodos y posibles vulnerabilidades.

## Prompt

```
Explora la API de un objetivo web y genera un informe con:
1. Endpoints públicos y privados
2. Métodos HTTP utilizados (GET, POST, PUT, DELETE, etc.)
3. Parámetros de consulta y cuerpo de request
4. Autenticación requerida (API key, OAuth, JWT, etc.)
5. Posibles vulnerabilidades en la API (injection, broken object level auth, etc.)

Usa herramientas como:
- curl, Postman, Insomnia
- Análisis de headers (X-Requested-With, etc.)
- Inspección de rutas no documentadas
```

## Variables
- `target`: URL del objetivo
- `output`: Formato de salida (JSON, tabla, markdown)

## Ejemplo de Uso

```
Descubre las APIs de https://api.example.com y genera un informe.
```

## Salida Esperada
Un listado de endpoints con detalles de la API.
```

## Notas
- Prioriza APIs que expongan datos sensibles.
- Verifica si hay rate limiting o autenticación.
- Documenta endpoints que podrían ser explotados (ej: endpoints de usuario sin validación).
```