# Subdomain Enumeration

## Contexto
Descubrir subdominios activos y no visitados en un objetivo para ampliar la superficie de ataque.

## Prompt

```
Analiza el objetivo web proporcionado y enumera todos los subdominios activos que encuentres. Para cada subdominio, incluye:
- Nombre del subdominio
- Tipo de dominio (comercial, institucional, etc.)
- Propósito potencial (servicio, API, portal, etc.)
- Estado de acceso (si es público o requiere autenticación)

Usa herramientas como sublist, amass, o enumeración manual con curl.
```

## Variables
- `target`: Dominio principal del objetivo (ej: example.com)
- `output`: Formato de salida deseado (JSON, tabla, texto)

## Ejemplo de Uso

```
Analiza el objetivo example.com y enumera los subdominios activos.
```

## Salida Esperada
Un listado de subdominios con información descriptiva, listo para integrar en un reporte.
```

## Notas
- Prioriza subdominios que parecen no visitados (no hay enlaces en el sitio).
- Verifica si son de terceros o propios del objetivo.
- Combina con enumeración de IPs y DNS records para mayor cobertura.
```